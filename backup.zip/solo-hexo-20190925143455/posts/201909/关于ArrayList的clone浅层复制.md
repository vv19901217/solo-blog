title: 关于ArrayList的clone（）浅层复制
date: '2019-09-25 10:44:51'
updated: '2019-09-25 13:58:54'
tags: [Android]
permalink: /articles/2019/09/25/1569379491064.html
---
&#8195;&#8195;正在看一篇关于从源码分析arrrylist的文章“arraylist实现了Cloneable接口，所以可以被复制，但是clone（）方法只是浅层复制。

## 首先要理解什么是浅层复制和深层复制

### 浅复制：

&#8195;&#8195;被复制对象的所有变量都含有与原来的对象相同的值，而所有的对其他对象的引用仍然指向原来的对象。换言之，浅复制仅仅复制所考虑的对象，而不复制它所引用的对象。

### 深复制：

&#8195;&#8195;被复制对象的所有变量都含有与原来的对象相同的值，除去那些引用其他对象的变量。那些引用其他对象的变量将指向被复制过的新对象，而不再是原有的那些被引用的对象。换言之，深复制把要复制的对象所引用的对象都复制了一遍。

  

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/A25FBB6892194963B0A900186C73A598/1279)

  

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/A9CA39219FF04D7BA9E2D06D38AC4905/1282)

  

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/8EE907CC311A44A3B4AC0D77850F9C03/1286)

&#8195;&#8195;简单说，对于ArrayList变量而言：浅复制指两个变量指示内存中的地址是不一样的，但是变量中的元素指向同一个元素。深拷贝是指，不仅仅变量指示的内存地址不一样，而且变量中的各个元素所指地址也是不一样的。

  

浅复制code 例子：

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/E6F81344B21A402285E262096B634329/1292)

打印结果

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/0025733F924748FCB54D35093E240083/1296)

  

深复制（使用二进制流来复制对象）

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/3644948C8A604B07A52E58B369CEA726/1300)

打印结果

![](https://note.youdao.com/yws/public/resource/e1e6e63353c7f0a6ae6819ad77077613/xmlnote/C1BBC415B44E4906BDC353939F70EA30/1303)
